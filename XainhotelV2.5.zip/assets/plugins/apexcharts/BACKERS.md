

## Our Backers and supporters

Financial contributions to ApexCharts go towards ongoing development costs, servers, etc. You can join them in supporting ApexCharts development by visiting our page on [Patreon](patreon.com/junedchhipa)!


### Sponsors
Become a sponsor and get your logo on our website's home-page with a link to your site. [[Become a sponsor](https://www.patreon.com/join/junedchhipa)]

## Platinum Sponsors

<a href="https://www.aputime.com?ref=apexcharts.com" target="_blank" style="text-align: center; display: inline-block;"><img src="https://apexcharts.com/media/sponsors/aputime.png" width="200" /></a>

### Backers
Support us with a monthly donation and help us continue our activities. [[Become a backer](https://www.patreon.com/join/junedchhipa/checkout?rid=3043800)].

Backer on | Name
-----|-----
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=10265776" target="_blank">Taillefer Brice</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=17096169" target="_blank">Thomas Janotta</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/calinou/creators" target="_blank">Hugo Locurcio</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=17230063" target="_blank">František Postl</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=3900260" target="_blank">Bob</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=15111755" target="_blank">Pierre Aguilar</a>
<img src="https://c10.patreonusercontent.com/3/eyJ3IjoyMDB9/patreon-media/p/user/7455917/731d8e3a06a146559c7a9cd44d53c5a0/1?token-time=2145916800&token-hash=X5Yg0cW2o7aaXLp09qGxtYzUiIX-15MlddbzMWIk89Y%3D" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=7455917" target="_blank">Maxim Demyanov</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=18184766" target="_blank">Harut</a>
<img src="https://c10.patreonusercontent.com/3/eyJ3IjoyMDB9/patreon-media/p/user/2406665/a420332e48ec49ffa5b902fa23d03382/1?token-time=2145916800&token-hash=CrsupRa6CKYV-CRoew8O1cGuXW97Wb2YwilNaInxRiY%3D" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=2406665" target="_blank">Ante Zivkovic</a>